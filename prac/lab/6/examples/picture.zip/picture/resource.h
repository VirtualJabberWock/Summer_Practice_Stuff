#ifndef _RESOURCE_H_
#define _RESOURCE_H_

#define IDM_OPEN    201
#define IDM_OPEN2   202
#define IDM_SAVE    203
#define IDM_INVERT  204
#define IDM_GRAYSTYLE   205

#endif  // _RESOURCE_H_
